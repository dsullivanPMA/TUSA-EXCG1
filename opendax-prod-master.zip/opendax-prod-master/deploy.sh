cd /root/opendax-prod
git pull 
source /usr/local/rvm/scripts/rvm
rake render:config